luadyncall 0.1

Dyncall bindings for Lua programming language C implementation.

CONTENTS
********
- smart pointer utility library (smartptr.so)
- dynload.lua, ldynload.so (dynload library)
- dyncall.lua (front end for Version 2 dyncall API), ldyncall.so (low-level lua dyncall bindings)
- dyncallback.lua, ldyncallback.so


