require"array"

x = array("i",10)
print(x.pointer)
x[1] = 23
print(x[1])
print(#x)
print(x.length)
