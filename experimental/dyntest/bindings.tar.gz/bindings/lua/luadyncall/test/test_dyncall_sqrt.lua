require "dyncall"

print( dyncall("@c/sqrt(d)d;", 144) )

