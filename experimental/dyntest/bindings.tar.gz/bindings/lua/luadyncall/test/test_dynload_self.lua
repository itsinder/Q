require"dynload"

x = dynload("")
print(x)

