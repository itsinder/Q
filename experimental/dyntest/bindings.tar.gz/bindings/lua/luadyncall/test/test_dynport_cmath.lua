require"dynport"
local cmath = dynportImport("cmath", { })
print(cmath)
print( cmath.sqrt(144) )

